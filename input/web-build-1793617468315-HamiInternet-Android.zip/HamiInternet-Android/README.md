# دليل مشروع حامي الإنترنت (Android Native)

يرجى مراجعة ملف README.md الكامل في مجلد android للاطلاع على خطوات تشغيل Android Studio وبناء ملف APK وتثبيته بالكامل.