package com.hami.internet.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.hami.internet.R
import com.hami.internet.data.PreferencesRepository
import com.hami.internet.security.PinSecurityManager
import com.hami.internet.service.ProtectionVpnService
import com.hami.internet.ui.components.PinDialog
import com.hami.internet.ui.screens.*
import com.hami.internet.ui.theme.DarkSurface
import com.hami.internet.ui.theme.EmeraldPrimary
import com.hami.internet.ui.theme.HamiInternetTheme
import com.hami.internet.ui.theme.TextMuted

class MainActivity : ComponentActivity() {

    private lateinit var preferencesRepo: PreferencesRepository
    private lateinit var pinManager: PinSecurityManager

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            launchVpnService()
        } else {
            Toast.makeText(this, getString(R.string.error_vpn_rejected), Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferencesRepo = PreferencesRepository(this)
        pinManager = PinSecurityManager(this)

        setContent {
            HamiInternetTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppContent()
                }
            }
        }
    }
}