package com.hami.internet.dns

import java.util.Locale

class DomainFilterEngine(
    private val customBlocklist: () -> Set<String>,
    private val customAllowlist: () -> Set<String>
) {

    private val adultTlds = hashSetOf(
        "xxx", "porn", "adult", "sex", "sexy", "cam", "tube", "fetish", "erotica"
    )

    private val adultKeywords = hashSetOf(
        "porn", "xxx", "xvideos", "xnxx", "pornhub", "xhamster", "redtube",
        "youporn", "chaturbate", "onlyfans", "brazzers", "cam4", "hentai",
        "stripchat", "livejasmin", "beeg", "spankbang", "eporner", "tube8",
        "tnaflix", "motherless", "bangbros", "erotic", "sexvid", "fapster",
        "naughty", "camsoda", "bongacams", "flirt4free", "imlive", "myfreecams",
        "youjizz", "pornmd", "tubegalore", "daftsex", "hqporner", "severeporn"
    )

    private val builtInAdultHosts = hashSetOf(
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com",
        "youporn.com", "chaturbate.com", "stripchat.com", "livejasmin.com",
        "spankbang.com", "eporner.com", "beeg.com", "tube8.com", "tnaflix.com",
        "brazzers.com", "bangbros.com", "naughtyamerica.com", "realitykings.com",
        "cam4.com", "camsoda.com", "bongacams.com", "myfreecams.com", "onlyfans.com",
        "fansly.com", "manyvids.com", "clips4sale.com", "fetlife.com"
    )

    fun shouldBlock(rawDomain: String): Boolean {
        val domain = rawDomain.trim().lowercase(Locale.ROOT)
            .removePrefix("www.")
            .removeSuffix(".")

        if (domain.isBlank()) return false

        val allowlist = customAllowlist()
        if (isDomainMatched(domain, allowlist)) return false

        val blocklist = customBlocklist()
        if (isDomainMatched(domain, blocklist)) return true

        if (builtInAdultHosts.contains(domain)) return true

        val lastDot = domain.lastIndexOf('.')
        if (lastDot != -1 && lastDot < domain.length - 1) {
            val tld = domain.substring(lastDot + 1)
            if (adultTlds.contains(tld)) return true
        }

        val parts = domain.split('.', '-', '_')
        for (part in parts) {
            if (adultKeywords.contains(part)) return true
        }

        return false
    }

    private fun isDomainMatched(target: String, list: Set<String>): Boolean {
        for (item in list) {
            val cleanItem = item.lowercase(Locale.ROOT).removePrefix("www.").removeSuffix(".")
            if (target == cleanItem || target.endsWith(".$cleanItem")) return true
        }
        return false
    }
}