# Keep AndroidX Security Crypto & Coroutines
-keep class androidx.security.crypto.** { *; }
-keepclassmembers class * {
    @androidx.room.* *;
}
-dontwarn java.lang.invoke.**
