package com.hami.internet.dns

import java.util.Locale

class DomainFilterEngine(
    private val customBlocklist: () -> Set<String>,
    private val customAllowlist: () -> Set<String>
) {

    // الامتدادات المخصصة حصرياً للمحتوى الجنسي
    private val adultTlds = hashSetOf(
        "xxx", "porn", "adult", "sex", "sexy", "cam", "tube", "fetish", "erotica"
    )

    // الكلمات المفتاحية الأكثر شيوعاً في نطاقات المواقع الإباحية العالمية
    private val adultKeywords = hashSetOf(
        "porn", "xxx", "xvideos", "xnxx", "pornhub", "xhamster", "redtube",
        "youporn", "chaturbate", "onlyfans", "brazzers", "cam4", "hentai",
        "stripchat", "livejasmin", "beeg", "spankbang", "eporner", "tube8",
        "tnaflix", "motherless", "bangbros", "erotic", "sexvid", "fapster",
        "naughty", "camsoda", "bongacams", "flirt4free", "imlive", "myfreecams",
        "youjizz", "pornmd", "tubegalore", "daftsex", "hqporner", "severeporn"
    )

    // نطاقات شهيرة ثابتة للمحتوى الجنسي لضمان الحجب الفوري
    private val builtInAdultHosts = hashSetOf(
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com",
        "youporn.com", "chaturbate.com", "stripchat.com", "livejasmin.com",
        "spankbang.com", "eporner.com", "beeg.com", "tube8.com", "tnaflix.com",
        "brazzers.com", "bangbros.com", "naughtyamerica.com", "realitykings.com",
        "cam4.com", "camsoda.com", "bongacams.com", "myfreecams.com", "onlyfans.com",
        "fansly.com", "manyvids.com", "clips4sale.com", "fetlife.com"
    )

    /**
     * يفحص ما إذا كان النطاق يجب حجبه
     * @return true إذا كان الموقع إباحياً أو مضافاً لقائمة الحظر
     */
    fun shouldBlock(rawDomain: String): Boolean {
        val domain = rawDomain.trim().lowercase(Locale.ROOT)
            .removePrefix("www.")
            .removeSuffix(".")

        if (domain.isBlank()) return false

        // 1. فحص قائمة السماح أولاً (لها الأولوية القصوى)
        val allowlist = customAllowlist()
        if (isDomainMatched(domain, allowlist)) {
            return false
        }

        // 2. فحص قائمة الحظر اليدوية التي أضافها المستخدم
        val blocklist = customBlocklist()
        if (isDomainMatched(domain, blocklist)) {
            return true
        }

        // 3. فحص النطاقات الثابتة
        if (builtInAdultHosts.contains(domain)) {
            return true
        }

        // 4. فحص لاحقة النطاق الأعلى (TLD)
        val lastDot = domain.lastIndexOf('.')
        if (lastDot != -1 && lastDot < domain.length - 1) {
            val tld = domain.substring(lastDot + 1)
            if (adultTlds.contains(tld)) {
                return true
            }
        }

        // 5. فحص الكلمات المفتاحية الصريحة داخل أجزاء النطاق
        val parts = domain.split('.', '-', '_')
        for (part in parts) {
            if (adultKeywords.contains(part)) {
                return true
            }
        }

        return false
    }

    private fun isDomainMatched(target: String, list: Set<String>): Boolean {
        for (item in list) {
            val cleanItem = item.lowercase(Locale.ROOT).removePrefix("www.").removeSuffix(".")
            if (target == cleanItem || target.endsWith(".$cleanItem")) {
                return true
            }
        }
        return false
    }
}
