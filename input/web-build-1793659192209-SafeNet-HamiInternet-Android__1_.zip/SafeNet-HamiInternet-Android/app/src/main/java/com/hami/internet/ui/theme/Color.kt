package com.hami.internet.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0B132B)
val DarkSurface = Color(0xFF1C2541)
val DarkSurfaceElevated = Color(0xFF273255)
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldLight = Color(0xFF34D399)
val EmeraldDark = Color(0xFF059669)
val CyanAccent = Color(0xFF06B6D4)
val DangerRose = Color(0xFFF43F5E)
val DangerDark = Color(0xFFE11D48)
val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val BorderDark = Color(0xFF334155)
