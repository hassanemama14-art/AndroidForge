package com.hami.internet.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class DnsFamilyServer(val displayName: String, val primaryIp: String, val secondaryIp: String) {
    CLEAN_BROWSING_FAMILY("CleanBrowsing (حماية عائلية صارمة)", "185.228.168.168", "185.228.169.168"),
    CLOUDFLARE_FAMILY("Cloudflare 1.1.1.3 (فلترة المحتوى الإباحي والبرمجيات الخبيثة)", "1.1.1.3", "1.0.0.3"),
    ADGUARD_FAMILY("AdGuard Family (حظر الإباحية والبحث الآمن)", "94.140.14.15", "94.140.15.16")
}

class PreferencesRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "hami_user_settings"
        private const val KEY_PROTECTION_ENABLED = "protection_enabled"
        private const val KEY_AUTO_START_BOOT = "auto_start_boot"
        private const val KEY_BLOCKLIST = "custom_blocklist"
        private const val KEY_ALLOWLIST = "custom_allowlist"
        private const val KEY_DNS_SERVER = "dns_server_type"
        private const val KEY_BLOCKED_COUNT = "blocked_queries_count"
    }

    private val _isProtectionActive = MutableStateFlow(prefs.getBoolean(KEY_PROTECTION_ENABLED, false))
    val isProtectionActive: StateFlow<Boolean> = _isProtectionActive.asStateFlow()

    private val _isAutoStartBoot = MutableStateFlow(prefs.getBoolean(KEY_AUTO_START_BOOT, true))
    val isAutoStartBoot: StateFlow<Boolean> = _isAutoStartBoot.asStateFlow()

    private val _blocklist = MutableStateFlow(prefs.getStringSet(KEY_BLOCKLIST, emptySet()) ?: emptySet())
    val blocklist: StateFlow<Set<String>> = _blocklist.asStateFlow()

    private val _allowlist = MutableStateFlow(prefs.getStringSet(KEY_ALLOWLIST, emptySet()) ?: emptySet())
    val allowlist: StateFlow<Set<String>> = _allowlist.asStateFlow()

    private val _selectedDns = MutableStateFlow(loadDnsServer())
    val selectedDns: StateFlow<DnsFamilyServer> = _selectedDns.asStateFlow()

    private val _blockedCount = MutableStateFlow(prefs.getInt(KEY_BLOCKED_COUNT, 0))
    val blockedCount: StateFlow<Int> = _blockedCount.asStateFlow()

    fun setProtectionActive(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PROTECTION_ENABLED, enabled).apply()
        _isProtectionActive.value = enabled
    }

    fun setAutoStartBoot(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_START_BOOT, enabled).apply()
        _isAutoStartBoot.value = enabled
    }

    fun addBlockedDomain(domain: String): Boolean {
        val cleanDomain = sanitizeDomain(domain)
        if (cleanDomain.isBlank()) return false
        val current = prefs.getStringSet(KEY_BLOCKLIST, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.add(cleanDomain)
        prefs.edit().putStringSet(KEY_BLOCKLIST, current).apply()
        _blocklist.value = current.toSet()
        return true
    }

    fun removeBlockedDomain(domain: String) {
        val current = prefs.getStringSet(KEY_BLOCKLIST, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.remove(domain)
        prefs.edit().putStringSet(KEY_BLOCKLIST, current).apply()
        _blocklist.value = current.toSet()
    }

    fun addAllowedDomain(domain: String): Boolean {
        val cleanDomain = sanitizeDomain(domain)
        if (cleanDomain.isBlank()) return false
        val current = prefs.getStringSet(KEY_ALLOWLIST, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.add(cleanDomain)
        prefs.edit().putStringSet(KEY_ALLOWLIST, current).apply()
        _allowlist.value = current.toSet()
        return true
    }

    fun removeAllowedDomain(domain: String) {
        val current = prefs.getStringSet(KEY_ALLOWLIST, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.remove(domain)
        prefs.edit().putStringSet(KEY_ALLOWLIST, current).apply()
        _allowlist.value = current.toSet()
    }

    fun setDnsServer(server: DnsFamilyServer) {
        prefs.edit().putString(KEY_DNS_SERVER, server.name).apply()
        _selectedDns.value = server
    }

    fun incrementBlockedCount() {
        val newCount = prefs.getInt(KEY_BLOCKED_COUNT, 0) + 1
        prefs.edit().putInt(KEY_BLOCKED_COUNT, newCount).apply()
        _blockedCount.value = newCount
    }

    private fun loadDnsServer(): DnsFamilyServer {
        val name = prefs.getString(KEY_DNS_SERVER, DnsFamilyServer.CLEAN_BROWSING_FAMILY.name)
        return try {
            DnsFamilyServer.valueOf(name ?: DnsFamilyServer.CLEAN_BROWSING_FAMILY.name)
        } catch (e: Exception) {
            DnsFamilyServer.CLEAN_BROWSING_FAMILY
        }
    }

    companion object DomainSanitizer {
        fun sanitizeDomain(input: String): String {
            var domain = input.trim().lowercase()
            if (domain.startsWith("http://")) domain = domain.substring(7)
            if (domain.startsWith("https://")) domain = domain.substring(8)
            val slashIndex = domain.indexOf('/')
            if (slashIndex != -1) domain = domain.substring(0, slashIndex)
            val portIndex = domain.indexOf(':')
            if (portIndex != -1) domain = domain.substring(0, portIndex)
            return domain
        }
    }
}
