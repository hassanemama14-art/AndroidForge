package com.hami.internet.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hami.internet.R
import com.hami.internet.data.DnsFamilyServer
import com.hami.internet.ui.theme.*

@Composable
fun HomeScreen(
    isProtected: Boolean,
    blockedCount: Int,
    selectedDns: DnsFamilyServer,
    onToggleProtection: () -> Unit
) {
    val shieldColor by animateColorAsState(
        targetValue = if (isProtected) EmeraldPrimary else DangerRose,
        animationSpec = tween(durationMillis = 400),
        label = "shieldColor"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // بطاقة الترويسة العلوية
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(shieldColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = shieldColor,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = stringResource(R.string.app_name),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Text(
                        text = if (isProtected) stringResource(R.string.status_protected) else stringResource(R.string.status_unprotected),
                        fontSize = 13.sp,
                        color = if (isProtected) EmeraldLight else DangerRose,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // زر الدرع الرئيسي الدائري الكبير
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(210.dp)
                    .shadow(
                        elevation = if (isProtected) 24.dp else 12.dp,
                        shape = CircleShape,
                        spotColor = shieldColor
                    )
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                shieldColor.copy(alpha = 0.35f),
                                DarkSurfaceElevated,
                                DarkSurface
                            )
                        )
                    )
                    .border(
                        width = 4.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(shieldColor, shieldColor.copy(alpha = 0.3f))
                        ),
                        shape = CircleShape
                    )
                    .clickable { onToggleProtection() },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (isProtected) Icons.Default.Shield else Icons.Default.PowerSettingsNew,
                        contentDescription = "زر تشغيل أو إيقاف الحماية",
                        tint = shieldColor,
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isProtected) "نشط" else "متوقف",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onToggleProtection,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isProtected) DangerDark else EmeraldPrimary
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(52.dp)
            ) {
                Text(
                    text = if (isProtected) stringResource(R.string.btn_disable_protection) else stringResource(R.string.btn_enable_protection),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = if (isProtected) stringResource(R.string.protection_active_desc) else stringResource(R.string.protection_inactive_desc),
                fontSize = 13.sp,
                color = TextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // إحصائيات وبطاقات الميزات السريعة
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // بطاقة عدد الاستعلامات المحجوبة
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "محاولات الحجب",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$blockedCount",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = EmeraldLight
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "تم منعها محلياً",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            // بطاقة خادم الـ DNS النشط
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "خادم الـ DNS",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedDns.name.split('_').firstOrNull() ?: "Clean",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = selectedDns.primaryIp,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // بطاقة ضمان الخصوصية
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "فلترة داخلية 100% بدون أي سجل تصفح أو خوادم وسيطة",
                fontSize = 11.sp,
                color = TextMuted
            )
        }
    }
}
