package com.hami.internet.dns

import android.net.VpnService
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer

class DnsPacketHandler(
    private val vpnService: VpnService,
    private val filterEngine: DomainFilterEngine,
    private val getUpstreamDnsIp: () -> String,
    private val onDomainBlocked: (String) -> Unit
) {

    companion object {
        private const val TAG = "HamiDnsHandler"
        private const val BUFFER_SIZE = 4096
        private const val DNS_PORT = 53
    }

    private var isRunning = false
    private var forwardingSocket: DatagramSocket? = null

    fun start(inputStream: FileInputStream, outputStream: FileOutputStream) {
        isRunning = true

        try {
            forwardingSocket = DatagramSocket().apply {
                vpnService.protect(this) // حماية مقبس الـ UDP من الوقوع في حلقة الـ VPN المفرغة
                soTimeout = 3000
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create protected DatagramSocket", e)
            return
        }

        val packetBuffer = ByteArray(BUFFER_SIZE)

        while (isRunning && !Thread.currentThread().isInterrupted) {
            try {
                val length = inputStream.read(packetBuffer)
                if (length <= 0) continue

                // فحص رأس بروتوكول IPv4
                if ((packetBuffer[0].toInt() and 0xF0) != 0x40) {
                    continue // تخطي الحزم غير التابعة لـ IPv4
                }

                val ipHeaderLength = (packetBuffer[0].toInt() and 0x0F) * 4
                val protocol = packetBuffer[9].toInt() and 0xFF

                // بروتوكول 17 هو UDP
                if (protocol != 17 || length < ipHeaderLength + 8) {
                    continue
                }

                val srcPort = ((packetBuffer[ipHeaderLength].toInt() and 0xFF) shl 8) or
                        (packetBuffer[ipHeaderLength + 1].toInt() and 0xFF)
                val dstPort = ((packetBuffer[ipHeaderLength + 2].toInt() and 0xFF) shl 8) or
                        (packetBuffer[ipHeaderLength + 3].toInt() and 0xFF)

                // استهداف استعلامات DNS الموجهة للمنفذ 53
                if (dstPort != DNS_PORT) {
                    continue
                }

                val udpHeaderLength = 8
                val dnsOffset = ipHeaderLength + udpHeaderLength
                val dnsLength = length - dnsOffset
                if (dnsLength < 12) continue // أقل حجم ترويسة DNS

                val dnsPayload = packetBuffer.copyOfRange(dnsOffset, length)
                val queriedDomain = extractDomainFromDns(dnsPayload)

                if (queriedDomain != null && filterEngine.shouldBlock(queriedDomain)) {
                    // حجب النطاق وإنشاء استجابة اصطناعية فورية ترجع 0.0.0.0
                    onDomainBlocked(queriedDomain)

                    val responseDns = buildBlockedDnsResponse(dnsPayload)
                    val responsePacket = buildUdpIpPacket(
                        srcIp = packetBuffer.copyOfRange(16, 20), // المصدر يصبح الوجهة السابقة
                        dstIp = packetBuffer.copyOfRange(12, 16), // الوجهة تصبح العميل
                        srcPort = dstPort,
                        dstPort = srcPort,
                        payload = responseDns
                    )

                    synchronized(outputStream) {
                        outputStream.write(responsePacket)
                        outputStream.flush()
                    }
                } else {
                    // النطاق مسموح: توجيهه لمزود الـ DNS العائلي المنقي عبر المقبس المحمي
                    forwardQueryUpstream(
                        dnsPayload = dnsPayload,
                        clientIp = packetBuffer.copyOfRange(12, 16),
                        clientPort = srcPort,
                        serverIp = packetBuffer.copyOfRange(16, 20),
                        outputStream = outputStream
                    )
                }

            } catch (e: Exception) {
                if (isRunning) {
                    Log.d(TAG, "DNS Packet cycle note: ${e.message}")
                }
            }
        }

        close()
    }

    fun stop() {
        isRunning = false
        close()
    }

    private fun close() {
        try {
            forwardingSocket?.close()
        } catch (_: Exception) {}
        forwardingSocket = null
    }

    /**
     * استخراج اسم النطاق من استعلام DNS (RFC 1035)
     */
    private fun extractDomainFromDns(dnsData: ByteArray): String? {
        try {
            var offset = 12 // بداية قسم Question بعد Header
            val domainBuilder = StringBuilder()

            while (offset < dnsData.size) {
                val len = dnsData[offset].toInt() and 0xFF
                if (len == 0) break // نهاية النطاق
                offset++
                if (offset + len > dnsData.size) return null

                if (domainBuilder.isNotEmpty()) {
                    domainBuilder.append('.')
                }
                domainBuilder.append(String(dnsData, offset, len, Charsets.US_ASCII))
                offset += len
            }
            return domainBuilder.toString().lowercase()
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * إنشاء استجابة DNS اصطناعية بحظر الموقع وإرجاع 0.0.0.0
     */
    private fun buildBlockedDnsResponse(queryDns: ByteArray): ByteArray {
        val buffer = ByteBuffer.allocate(queryDns.size + 16)
        // 1. Transaction ID
        buffer.put(queryDns[0])
        buffer.put(queryDns[1])

        // 2. Flags: 0x8180 (Standard query response, No error)
        buffer.put(0x81.toByte())
        buffer.put(0x80.toByte())

        // 3. QDCOUNT (1)
        buffer.put(queryDns[4])
        buffer.put(queryDns[5])

        // 4. ANCOUNT (1 Answer)
        buffer.put(0x00.toByte())
        buffer.put(0x01.toByte())

        // 5. NSCOUNT (0) & ARCOUNT (0)
        buffer.put(0x00.toByte())
        buffer.put(0x00.toByte())
        buffer.put(0x00.toByte())
        buffer.put(0x00.toByte())

        // 6. نسخ قسم السؤال Question Section بالكامل
        val qdLength = findQuestionSectionLength(queryDns)
        buffer.put(queryDns, 12, qdLength)

        // 7. قسم الإجابة (Answer Record)
        // Name Pointer يشير إلى اسم السؤال في الإزاحة 12 (0xc00c)
        buffer.put(0xc0.toByte())
        buffer.put(0x0c.toByte())

        // Type: A Record (0x0001)
        buffer.put(0x00.toByte())
        buffer.put(0x01.toByte())

        // Class: IN (0x0001)
        buffer.put(0x00.toByte())
        buffer.put(0x01.toByte())

        // TTL: 300 ثانية
        buffer.putInt(300)

        // Data Length: 4 بايت (IPv4)
        buffer.putShort(4.toShort())

        // IP المحجوب: 0.0.0.0 (Refused/Blocked IP)
        buffer.put(0x00.toByte())
        buffer.put(0x00.toByte())
        buffer.put(0x00.toByte())
        buffer.put(0x00.toByte())

        return buffer.array().copyOf(buffer.position())
    }

    private fun findQuestionSectionLength(dnsData: ByteArray): Int {
        var offset = 12
        while (offset < dnsData.size) {
            val len = dnsData[offset].toInt() and 0xFF
            if (len == 0) {
                // 0 byte + 2 bytes Type + 2 bytes Class = 5 bytes
                return (offset + 5) - 12
            }
            offset += (len + 1)
        }
        return dnsData.size - 12
    }

    /**
     * تمرير استعلام الـ DNS النظيف إلى خادم DNS العائلي المنقّي عبر الشبكة الحقيقية
     */
    private fun forwardQueryUpstream(
        dnsPayload: ByteArray,
        clientIp: ByteArray,
        clientPort: Int,
        serverIp: ByteArray,
        outputStream: FileOutputStream
    ) {
        val socket = forwardingSocket ?: return
        try {
            val upstreamIpStr = getUpstreamDnsIp()
            val upstreamAddress = InetAddress.getByName(upstreamIpStr)
            val sendPacket = DatagramPacket(dnsPayload, dnsPayload.size, upstreamAddress, DNS_PORT)
            socket.send(sendPacket)

            val receiveBuffer = ByteArray(BUFFER_SIZE)
            val receivePacket = DatagramPacket(receiveBuffer, receiveBuffer.size)
            socket.receive(receivePacket)

            val receivedDns = receiveBuffer.copyOf(receivePacket.length)

            val responsePacket = buildUdpIpPacket(
                srcIp = serverIp,
                dstIp = clientIp,
                srcPort = DNS_PORT,
                dstPort = clientPort,
                payload = receivedDns
            )

            synchronized(outputStream) {
                outputStream.write(responsePacket)
                outputStream.flush()
            }
        } catch (_: Exception) {
            // يمكن أن يحدث انتهاء مهلة في الشبكات البطيئة وهو سلوك طبيعي في UDP
        }
    }

    /**
     * بناء حزمة IPv4 + UDP كاملة مع حساب المجموع الاختباري (Checksum)
     */
    private fun buildUdpIpPacket(
        srcIp: ByteArray,
        dstIp: ByteArray,
        srcPort: Int,
        dstPort: Int,
        payload: ByteArray
    ): ByteArray {
        val ipHeaderLen = 20
        val udpHeaderLen = 8
        val totalLen = ipHeaderLen + udpHeaderLen + payload.size
        val packet = ByteArray(totalLen)
        val buf = ByteBuffer.wrap(packet)

        // IP Header
        buf.put(0x45.toByte()) // Version 4, IHL 5 (20 bytes)
        buf.put(0x00.toByte()) // DSCP/ECN
        buf.putShort(totalLen.toShort()) // Total length
        buf.putShort(0.toShort()) // ID
        buf.putShort(0x4000.toShort()) // Flags (Don't Fragment)
        buf.put(64.toByte()) // TTL
        buf.put(17.toByte()) // Protocol: UDP
        buf.putShort(0.toShort()) // Checksum (محسوب لاحقاً)
        buf.put(srcIp)
        buf.put(dstIp)

        // حساب IP Checksum
        val ipChecksum = computeIpChecksum(packet, 0, ipHeaderLen)
        packet[10] = (ipChecksum shr 8).toByte()
        packet[11] = (ipChecksum and 0xFF).toByte()

        // UDP Header
        buf.position(ipHeaderLen)
        buf.putShort(srcPort.toShort())
        buf.putShort(dstPort.toShort())
        buf.putShort((udpHeaderLen + payload.size).toShort())
        buf.putShort(0.toShort()) // UDP Checksum (0 تعني غير مفعل في IPv4)
        buf.put(payload)

        return packet
    }

    private fun computeIpChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0
        var i = offset
        while (i < offset + length) {
            val high = data[i].toInt() and 0xFF
            val low = data[i + 1].toInt() and 0xFF
            sum += (high shl 8) or low
            i += 2
        }
        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return sum.inv() and 0xFFFF
    }
}
