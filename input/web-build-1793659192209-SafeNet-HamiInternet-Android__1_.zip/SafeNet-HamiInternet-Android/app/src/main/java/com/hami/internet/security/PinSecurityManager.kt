package com.hami.internet.security

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom
import android.util.Base64

class PinSecurityManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "hami_security_prefs"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_PIN_ENABLED = "pin_enabled"
        private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
        private const val KEY_LOCKOUT_UNTIL = "lockout_until"
        private const val MAX_ATTEMPTS = 5
        private const val LOCKOUT_DURATION_MS = 30_000L // 30 ثانية حظر مؤقت بعد 5 محاولات خاطئة
    }

    fun isPinConfigured(): Boolean {
        return prefs.getBoolean(KEY_PIN_ENABLED, false) && prefs.getString(KEY_PIN_HASH, null) != null
    }

    fun setPin(pin: String): Boolean {
        if (pin.length != 4 || !pin.all { it.isDigit() }) {
            return false
        }
        val salt = generateSalt()
        val hash = hashPin(pin, salt)

        prefs.edit()
            .putString(KEY_PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_PIN_HASH, hash)
            .putBoolean(KEY_PIN_ENABLED, true)
            .putInt(KEY_FAILED_ATTEMPTS, 0)
            .putLong(KEY_LOCKOUT_UNTIL, 0L)
            .apply()
        return true
    }

    fun verifyPin(pin: String): PinVerificationResult {
        if (!isPinConfigured()) {
            return PinVerificationResult.Success
        }

        val currentTime = System.currentTimeMillis()
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        if (currentTime < lockoutUntil) {
            val remainingSec = ((lockoutUntil - currentTime) / 1000).toInt()
            return PinVerificationResult.LockedOut(remainingSec)
        }

        val saltBase64 = prefs.getString(KEY_PIN_SALT, null) ?: return PinVerificationResult.Incorrect(0)
        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return PinVerificationResult.Incorrect(0)
        val salt = Base64.decode(saltBase64, Base64.NO_WRAP)
        val computedHash = hashPin(pin, salt)

        if (computedHash == storedHash) {
            prefs.edit()
                .putInt(KEY_FAILED_ATTEMPTS, 0)
                .putLong(KEY_LOCKOUT_UNTIL, 0L)
                .apply()
            return PinVerificationResult.Success
        } else {
            val attempts = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
            if (attempts >= MAX_ATTEMPTS) {
                val newLockout = System.currentTimeMillis() + LOCKOUT_DURATION_MS
                prefs.edit()
                    .putInt(KEY_FAILED_ATTEMPTS, 0)
                    .putLong(KEY_LOCKOUT_UNTIL, newLockout)
                    .apply()
                return PinVerificationResult.LockedOut((LOCKOUT_DURATION_MS / 1000).toInt())
            } else {
                prefs.edit().putInt(KEY_FAILED_ATTEMPTS, attempts).apply()
                return PinVerificationResult.Incorrect(MAX_ATTEMPTS - attempts)
            }
        }
    }

    private fun generateSalt(): ByteArray {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        return salt
    }

    private fun hashPin(pin: String, salt: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        val hashBytes = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(hashBytes, Base64.NO_WRAP)
    }

    sealed class PinVerificationResult {
        object Success : PinVerificationResult()
        data class Incorrect(val remainingAttempts: Int) : PinVerificationResult()
        data class LockedOut(val remainingSeconds: Int) : PinVerificationResult()
    }
}
