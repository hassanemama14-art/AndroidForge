package com.hami.internet.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.hami.internet.HamiApplication
import com.hami.internet.R
import com.hami.internet.data.PreferencesRepository
import com.hami.internet.dns.DnsPacketHandler
import com.hami.internet.dns.DomainFilterEngine
import com.hami.internet.ui.MainActivity
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

class ProtectionVpnService : VpnService() {

    companion object {
        private const val TAG = "ProtectionVpnService"
        const val ACTION_START = "com.hami.internet.action.START"
        const val ACTION_STOP = "com.hami.internet.action.STOP"
        private const val NOTIFICATION_ID = 1001

        val isRunning = AtomicBoolean(false)
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var dnsWorkerThread: Thread? = null
    private var dnsHandler: DnsPacketHandler? = null
    private lateinit var preferencesRepo: PreferencesRepository
    private lateinit var filterEngine: DomainFilterEngine

    override fun onCreate() {
        super.onCreate()
        preferencesRepo = PreferencesRepository(this)
        filterEngine = DomainFilterEngine(
            customBlocklist = { preferencesRepo.blocklist.value },
            customAllowlist = { preferencesRepo.allowlist.value }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        if (action == ACTION_STOP) {
            stopProtection()
            return START_NOT_STICKY
        }

        startProtection()
        return START_STICKY
    }

    private fun startProtection() {
        if (isRunning.get()) {
            return
        }

        try {
            startForeground(NOTIFICATION_ID, buildForegroundNotification())

            val selectedDns = preferencesRepo.selectedDns.value
            val builder = Builder()
                .setSession(getString(R.string.app_name))
                .setMtu(1500)
                // تعيين عنوان واجهة TUN المحلية
                .addAddress("10.250.0.2", 24)
                // توجيه استعلامات DNS لواجهة الـ TUN المحلية ولخوادم الـ DNS العائلية
                .addDnsServer("10.250.0.1")
                .addDnsServer(selectedDns.primaryIp)
                .addDnsServer(selectedDns.secondaryIp)
                // مسارات استعلامات DNS
                .addRoute("10.250.0.1", 32)
                .addRoute(selectedDns.primaryIp, 32)
                .addRoute(selectedDns.secondaryIp, 32)

            // استثناء حزم تطبيق حامي الإنترنت نفسه من نفق الـ VPN لتجنب أي تعارض
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    builder.addDisallowedApplication(packageName)
                }
            } catch (_: Exception) {}

            vpnInterface = builder.establish()

            if (vpnInterface == null) {
                Log.e(TAG, "VPN Interface establishment returned null")
                stopSelf()
                return
            }

            isRunning.set(true)
            preferencesRepo.setProtectionActive(true)

            val pfd = vpnInterface!!
            val inputStream = FileInputStream(pfd.fileDescriptor)
            val outputStream = FileOutputStream(pfd.fileDescriptor)

            dnsHandler = DnsPacketHandler(
                vpnService = this,
                filterEngine = filterEngine,
                getUpstreamDnsIp = { preferencesRepo.selectedDns.value.primaryIp },
                onDomainBlocked = { _ ->
                    preferencesRepo.incrementBlockedCount()
                }
            )

            dnsWorkerThread = Thread {
                dnsHandler?.start(inputStream, outputStream)
            }.apply {
                name = "HamiDnsWorker"
                start()
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error starting Protection VPN", e)
            stopProtection()
        }
    }

    private fun stopProtection() {
        isRunning.set(false)
        preferencesRepo.setProtectionActive(false)

        dnsHandler?.stop()
        dnsWorkerThread?.interrupt()
        dnsWorkerThread = null

        try {
            vpnInterface?.close()
        } catch (_: Exception) {}
        vpnInterface = null

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildForegroundNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpenApp = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, HamiApplication.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_shield_protected)
            .setContentTitle(getString(R.string.notification_title_active))
            .setContentText(getString(R.string.notification_content_active))
            .setContentIntent(pendingOpenApp)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET) // حماية تامة للخصوصية في شاشة القفل
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        stopProtection()
        super.onDestroy()
    }

    override fun onRevoke() {
        // يتم استدعاؤها في حال ألغى النظام إذن الـ VPN
        stopProtection()
        super.onRevoke()
    }
}
