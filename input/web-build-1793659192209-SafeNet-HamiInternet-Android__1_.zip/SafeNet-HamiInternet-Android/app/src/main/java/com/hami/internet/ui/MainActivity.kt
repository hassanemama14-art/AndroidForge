package com.hami.internet.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.hami.internet.R
import com.hami.internet.data.PreferencesRepository
import com.hami.internet.security.PinSecurityManager
import com.hami.internet.service.ProtectionVpnService
import com.hami.internet.ui.components.PinDialog
import com.hami.internet.ui.screens.*
import com.hami.internet.ui.theme.DarkSurface
import com.hami.internet.ui.theme.EmeraldPrimary
import com.hami.internet.ui.theme.HamiInternetTheme
import com.hami.internet.ui.theme.TextMuted

enum class NavigationTab {
    HOME, BLOCKLIST, ALLOWLIST, SETTINGS
}

class MainActivity : ComponentActivity() {

    private lateinit var preferencesRepo: PreferencesRepository
    private lateinit var pinManager: PinSecurityManager

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            launchVpnService()
        } else {
            Toast.makeText(this, getString(R.string.error_vpn_rejected), Toast.LENGTH_LONG).show()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Permission granted or denied */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferencesRepo = PreferencesRepository(this)
        pinManager = PinSecurityManager(this)

        // طلب إذن الإشعارات لأندرويد 13 فما فوق
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            HamiInternetTheme {
                // تفعيل اتجاه الواجهة من اليمين إلى اليسار (RTL) لجميع الشاشات
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppContent()
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun MainAppContent() {
        val isProtected by preferencesRepo.isProtectionActive.collectAsState()
        val blockedCount by preferencesRepo.blockedCount.collectAsState()
        val selectedDns by preferencesRepo.selectedDns.collectAsState()
        val isAutoStart by preferencesRepo.isAutoStartBoot.collectAsState()
        val blocklist by preferencesRepo.blocklist.collectAsState()
        val allowlist by preferencesRepo.allowlist.collectAsState()

        var currentTab by remember { mutableStateOf(NavigationTab.HOME) }

        // حالات حوار رمز PIN
        var showPinPromptForDisable by remember { mutableStateOf(false) }
        var showPinPromptForNewPin by remember { mutableStateOf(false) }
        var pinErrorMessage by remember { mutableStateOf<String?>(null) }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = when (currentTab) {
                                NavigationTab.HOME -> stringResource(R.string.app_name)
                                NavigationTab.BLOCKLIST -> stringResource(R.string.tab_blocklist)
                                NavigationTab.ALLOWLIST -> stringResource(R.string.tab_allowlist)
                                NavigationTab.SETTINGS -> stringResource(R.string.tab_settings)
                            }
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkSurface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentTab == NavigationTab.HOME,
                        onClick = { currentTab = NavigationTab.HOME },
                        icon = { Icon(Icons.Default.Shield, contentDescription = null) },
                        label = { Text(stringResource(R.string.tab_home)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == NavigationTab.BLOCKLIST,
                        onClick = { currentTab = NavigationTab.BLOCKLIST },
                        icon = { Icon(Icons.Default.Block, contentDescription = null) },
                        label = { Text(stringResource(R.string.tab_blocklist)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == NavigationTab.ALLOWLIST,
                        onClick = { currentTab = NavigationTab.ALLOWLIST },
                        icon = { Icon(Icons.Default.CheckCircle, contentDescription = null) },
                        label = { Text(stringResource(R.string.tab_allowlist)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                    NavigationBarItem(
                        selected = currentTab == NavigationTab.SETTINGS,
                        onClick = { currentTab = NavigationTab.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text(stringResource(R.string.tab_settings)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                }
            }
        ) { paddingValues ->
            Box(modifier = Modifier.padding(paddingValues)) {
                when (currentTab) {
                    NavigationTab.HOME -> {
                        HomeScreen(
                            isProtected = isProtected,
                            blockedCount = blockedCount,
                            selectedDns = selectedDns,
                            onToggleProtection = {
                                if (isProtected) {
                                    // عند محاولة إيقاف الحماية: فحص رمز PIN إن وجد لمنع التلاعب
                                    if (pinManager.isPinConfigured()) {
                                        pinErrorMessage = null
                                        showPinPromptForDisable = true
                                    } else {
                                        stopVpnService()
                                    }
                                } else {
                                    requestStartProtection()
                                }
                            }
                        )
                    }
                    NavigationTab.BLOCKLIST -> {
                        BlocklistScreen(
                            blocklist = blocklist,
                            onAddDomain = { domain ->
                                val added = preferencesRepo.addBlockedDomain(domain)
                                if (added) {
                                    Toast.makeText(this@MainActivity, getString(R.string.domain_added_success), Toast.LENGTH_SHORT).show()
                                }
                                added
                            },
                            onRemoveDomain = { domain ->
                                preferencesRepo.removeBlockedDomain(domain)
                                Toast.makeText(this@MainActivity, getString(R.string.domain_deleted_success), Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    NavigationTab.ALLOWLIST -> {
                        AllowlistScreen(
                            allowlist = allowlist,
                            onAddDomain = { domain ->
                                val added = preferencesRepo.addAllowedDomain(domain)
                                if (added) {
                                    Toast.makeText(this@MainActivity, getString(R.string.domain_added_success), Toast.LENGTH_SHORT).show()
                                }
                                added
                            },
                            onRemoveDomain = { domain ->
                                preferencesRepo.removeAllowedDomain(domain)
                                Toast.makeText(this@MainActivity, getString(R.string.domain_deleted_success), Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    NavigationTab.SETTINGS -> {
                        SettingsScreen(
                            isAutoStart = isAutoStart,
                            onToggleAutoStart = { preferencesRepo.setAutoStartBoot(it) },
                            selectedDns = selectedDns,
                            onSelectDns = { preferencesRepo.setDnsServer(it) },
                            isPinSet = pinManager.isPinConfigured(),
                            onChangePinClicked = {
                                pinErrorMessage = null
                                showPinPromptForNewPin = true
                            }
                        )
                    }
                }

                // نافذة طلب رمز PIN لإيقاف الحماية
                if (showPinPromptForDisable) {
                    PinDialog(
                        title = stringResource(R.string.pin_title_enter),
                        description = stringResource(R.string.pin_desc_enter),
                        errorMessage = pinErrorMessage,
                        onPinEntered = { pin ->
                            when (val result = pinManager.verifyPin(pin)) {
                                is PinSecurityManager.PinVerificationResult.Success -> {
                                    showPinPromptForDisable = false
                                    pinErrorMessage = null
                                    stopVpnService()
                                }
                                is PinSecurityManager.PinVerificationResult.Incorrect -> {
                                    pinErrorMessage = "رمز غير صحيح. المتبقي: ${result.remainingAttempts} محاولات"
                                }
                                is PinSecurityManager.PinVerificationResult.LockedOut -> {
                                    pinErrorMessage = "تم تجميد المحاولات مؤقتاً لمدة ${result.remainingSeconds} ثانية"
                                }
                            }
                        },
                        onDismiss = {
                            showPinPromptForDisable = false
                            pinErrorMessage = null
                        }
                    )
                }

                // نافذة تعيين أو تغيير رمز PIN
                if (showPinPromptForNewPin) {
                    PinDialog(
                        title = stringResource(R.string.pin_title_create),
                        description = stringResource(R.string.pin_desc_create),
                        errorMessage = pinErrorMessage,
                        onPinEntered = { newPin ->
                            val success = pinManager.setPin(newPin)
                            if (success) {
                                showPinPromptForNewPin = false
                                pinErrorMessage = null
                                Toast.makeText(this@MainActivity, getString(R.string.pin_success_set), Toast.LENGTH_SHORT).show()
                            } else {
                                pinErrorMessage = "يجب أن يتكون الرمز من 4 أرقام"
                            }
                        },
                        onDismiss = {
                            showPinPromptForNewPin = false
                            pinErrorMessage = null
                        }
                    )
                }
            }
        }
    }

    private fun requestStartProtection() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            launchVpnService()
        }
    }

    private fun launchVpnService() {
        val intent = Intent(this, ProtectionVpnService::class.java).apply {
            action = ProtectionVpnService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopVpnService() {
        val intent = Intent(this, ProtectionVpnService::class.java).apply {
            action = ProtectionVpnService.ACTION_STOP
        }
        startService(intent)
    }
}
