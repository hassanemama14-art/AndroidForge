package com.hami.internet.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat
import com.hami.internet.data.PreferencesRepository
import com.hami.internet.service.ProtectionVpnService

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return

        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val prefs = PreferencesRepository(context)

            // التحقق من تفعيل خيار التشغيل التلقائي عند بدء التشغيل
            if (prefs.isAutoStartBoot.value) {
                // التأكد من أن إذن الـ VPN تم منحه مسبقاً من المستخدم
                val vpnIntent = VpnService.prepare(context)
                if (vpnIntent == null) {
                    val serviceIntent = Intent(context, ProtectionVpnService::class.java).apply {
                        this.action = ProtectionVpnService.ACTION_START
                    }
                    ContextCompat.startForegroundService(context, serviceIntent)
                }
            }
        }
    }
}
