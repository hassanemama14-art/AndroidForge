# تطبيق حامي الإنترنت (SafeNet - HamiInternet)

مشروع أندرويد Native متكامل جاهز للبناء في Android Studio واستخراج ملف APK مباشرة.
يحتوي المشروع على جميع أيقونات التطبيق التكيفية والصورية (ic_launcher و ic_launcher_round) بجميع الكثافات.

## خطوات البناء:
1. افتح مجلد المشروع في Android Studio.
2. انتظر اكتمال Gradle Sync.
3. اضغط: Build -> Build Bundle(s) / APK(s) -> Build APK(s)
4. ستجد ملف APK في: app/build/outputs/apk/debug/app-debug.apk
